package at.kaindorf.emp.pojos;

public enum Gender {
    M, F
}
