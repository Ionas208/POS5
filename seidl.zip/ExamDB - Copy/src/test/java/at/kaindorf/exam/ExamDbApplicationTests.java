package at.kaindorf.exam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamDbApplicationTests {

    @Test
    void contextLoads() {
    }

}
