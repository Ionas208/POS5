package at.kaindorf.plf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlfUbungApplicationTests {

    @Test
    void contextLoads() {
    }

}
