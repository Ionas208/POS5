package at.kaindorf.plf.pojos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*
    Created by: Jonas Seidl
    Date: 27.01.2022
    Time: 12:00
*/
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Util {
    private Integer chosenDeptNo;
    private Employee emp2Insert;
}
